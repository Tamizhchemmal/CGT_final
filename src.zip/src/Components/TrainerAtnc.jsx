import React from "react";

function TrainerAtnc() {
  return <></>;
}

export default TrainerAtnc;
